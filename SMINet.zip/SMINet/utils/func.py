# coding=utf-8
import os


# create folders
def check_mkdir(dir_name):
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)


















